#include <vorbis/codec.h>
#include <vorbis/vorbisfile.h>

int	_fseek64_wrap(FILE *f,ogg_int64_t off,int whence);
